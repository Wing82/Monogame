This section explains the various command line tools that are part of MonoGame.

  - [2MGFX](2mgfx.md) is used to compile stand alone effects.
  - [MGCB](mgcb.md) is used to build content pipeline content.
