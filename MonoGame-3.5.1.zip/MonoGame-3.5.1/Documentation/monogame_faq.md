This page contains a list of frequently asked questions.

### What software do I need to start?

Depending on the platform you wish to develop for the following thing are needed:
 - Android - You need Xamarin.Android: http://android.xamarin.com/, it works on Windows and Mac and it can be used in combination with either Visual Studio or Xamarin Studio.
 - iOS - You need Xamarin.iOS: http://ios.xamarin.com/, it works on Windows and Mac and it can be used in combination with either Visual Studio or Xamarin Studio.
