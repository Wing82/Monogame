using System;

namespace MonoDevelop.MonoGame.Core
{
	public interface IMonoGameProject
	{
	}
}

